//
//  AuthenticationController.swift
//  TravelBook
//
//  Created by skrzymo on 23/01/2019.
//  Copyright © 2019 skrzymo. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import FBSDKCoreKit

struct UserDetails {
    static var name: String!
    static var image: UIImage!
}

class AuthenticationController: UIViewController ,FBSDKLoginButtonDelegate {
    
    @IBOutlet weak var facebookLoginButton: FBSDKLoginButton!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        facebookLoginButton.delegate = self
        facebookLoginButton.readPermissions = ["public_profile", "email"]
        
        /*if FBSDKAccessToken.current() != nil {
            fetchProfile()
            print(UserDetails.image)
            performSegue(withIdentifier: "afterSignInSegue", sender: nil)
        }*/
        
    }
    
    func fetchProfile() {
        let parameters = ["fields": "name, picture"]
        FBSDKGraphRequest(graphPath: "me", parameters: parameters)?.start { (connection, result, error) -> Void in
            if error != nil {
                print(error)
                return
            }
            
            if let userInfo = result as? [String: Any] {
                UserDetails.name = userInfo["name"] as? String
                do {
                    if let picture = userInfo["picture"] as? NSDictionary, let data = picture["data"] as? NSDictionary, let url = data["url"] as? String {
                        let imageURL = URL(string: url)
                        let imageData = try Data(contentsOf: imageURL!)
                        UserDetails.image = UIImage(data: imageData)
                    }
                } catch let parseError as NSError {
                    print(parseError)
                }
                
            }
        }
    }
    
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        if let error = error {
            print("Error took place \(error.localizedDescription)")
            return
        }
        fetchProfile()
        performSegue(withIdentifier: "afterSignInSegue", sender: nil)
        print("Success")
    }
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        print("User signed out")
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "afterSignInSegue" {
            let listViewController = segue.destination as! UINavigationController
            listViewController.title = "TravelBook"
        }
    }   
    
}

