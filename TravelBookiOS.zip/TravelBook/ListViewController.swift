//
//  ListViewController.swift
//  TravelBook
//
//  Created by skrzymo on 24/01/2019.
//  Copyright © 2019 skrzymo. All rights reserved.
//

import UIKit
import CoreData
import FBSDKLoginKit
import FBSDKCoreKit

var countries: [NSManagedObject] = []

class ListViewController: UIViewController {

    @IBOutlet weak var logoutButton: UIBarButtonItem!
    @IBOutlet var nameLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var addPlaceButton: UIBarButtonItem!
    @IBOutlet weak var deletePlaceButton: UIBarButtonItem!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        nameLabel.text = UserDetails.name
        //tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "Cell")
        tableView.reloadData()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        if FBSDKAccessToken.current() == nil {
            let main = UIStoryboard(name: "Main", bundle: Bundle.main)
            let authenticate = main.instantiateViewController(withIdentifier: "Authentication")
            
            self.present(authenticate, animated: true, completion: nil)
        }
        
        fetchProfile()
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
        }
        
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Places")
        
        do {
            countries = try managedContext.fetch(fetchRequest)
        } catch let error as NSError {
            print("Could not fetch. \(error), \(error.userInfo)")
        }
        
        tableView.reloadData()
        print(countries)
    }
    
    func fetchProfile() {
        let parameters = ["fields": "name, picture"]
        FBSDKGraphRequest(graphPath: "me", parameters: parameters)?.start { (connection, result, error) -> Void in
            if error != nil {
                print(error)
                return
            }
            
            if let userInfo = result as? [String: Any] {
                UserDetails.name = userInfo["name"] as? String
                do {
                    if let picture = userInfo["picture"] as? NSDictionary, let data = picture["data"] as? NSDictionary, let url = data["url"] as? String {
                        let imageURL = URL(string: url)
                        let imageData = try Data(contentsOf: imageURL!)
                        UserDetails.image = UIImage(data: imageData)
                    }
                } catch let parseError as NSError {
                    print(parseError)
                }
                
            }
        }
    }
    
    @IBAction func addPlaceAction(_ sender: Any) {
        performSegue(withIdentifier: "addPlace", sender: nil)
    }
    
    @IBAction func deletePlaceAction(_ sender: Any) {
        performSegue(withIdentifier: "deletePlace", sender: nil)
    }
    @IBAction func logoutAction(_ sender: Any) {
        performSegue(withIdentifier: "logout", sender: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "addPlace" {
            let addController = segue.destination as! UINavigationController
            addController.title = "AddPlace"
        } else if segue.identifier == "deletePlace" {
            let deleteController = segue.destination as! DeleteController
            deleteController.title = "DeletePlace"
        } else if segue.identifier == "logout" {
            let logoutController = segue.destination as! AuthenticationController
            logoutController.title = "Logout"
        }
    }
}
    
extension ListViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return countries.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let country = countries[indexPath.row]
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = country.value(forKeyPath: "country") as? String
        return cell
    }
}


